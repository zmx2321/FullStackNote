<template>
  <div style="width:100%;height:100%;">
    <div id="container">
      <slot></slot>
    </div>
  </div>
</template>

<script>
/**
 * write a component's description
 */
import _Motor from "@/library/motor.js";
import infos from "@/config/infos.json";
import Cesium from "cesium/Source/Cesium";
const Motor = window.Motor;
const appid = "15817c182f79432e80b1ee5969ed100f";
const secret = "459dc8b77a63a0c009aec27f818febf6";
const id = "fa8169-bdf4-4aba-b401-7ae0395306da";
import { Evented } from "../utils/handler";
Motor.ServiceConfig.server = "http://webapi.geointech.cn/api";
const projectId = "ac535b15-bc86-4189-9672-660b719ea3d0";
let viewer = null,
  modelColor = new Motor.Color(102 / 255, 204 / 255, 1.0, 0.5),
  markers = null,
  floatAttribute = null,
  handler = new Evented(),
  floating = false;
export default {
  name: "Scene",
  data() {
    return {
    };
  },
  props: {
    isLight: {
      type: Boolean,
      default: true
    },
    floor: Number,
    editMode: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    changeFloor(num, needZoom) {
      let components = viewer.currentScene.projectList[0].components;
      if (num < 11) {
        for (let component of components) {
          if (infos.floor[component.guid] === num) {
            component.setColor(modelColor);
          } else {
            component.setColor(new Motor.Color(1.0, 1.0, 1.0, 0.0));
          }
          if (infos.floor[component.guid] === num && needZoom) {
            viewer.zoomToComponent(component, function() {
              viewer.setLookAtCenter();
            });
          }
        }
      } else {
        viewer.currentScene.setColorForAll(modelColor);
        if (needZoom) viewer.gotoDefaultProjectView();
      }
    },
    /**
     * @description
     * @param {any} coordinate 标注坐标
     * @param {any} id  标注id
     * @param {any} image 标注图片
     * @param {any} properties = {} 标注属性(包含图片和高亮图片) 
     */
    addMarker({ coordinate, id, image, properties = {} }) {
      markers.add({
        id: id,
        position: {
          cartesian: [coordinate.x, coordinate.y, coordinate.z]
        },
        billboard: {
          image: image, //图片地址
          verticalOrigin: "BOTTOM",
          horizontalOrigin: "CENTER",
          disableDepthTestDistance: 20
          // sizeInMeters:true,
          // scale:0.01
        },
        properties: {
          type: "marker",
          img: image,
          ...properties
        }
      });

      markers.staticCzmlDataSource.entities.getById(
        id
      ).billboard.scaleByDistance = new Cesium.NearFarScalar(
        20.0,
        1.5,
        100,
        0.4
      );
      // console.log(markers.staticCzmlDataSource.entities.getById(id).billboard);
    },
  
    /**
     * @description 移除标注
     * @param {any} id
     */
    removeMarker(id) {
      markers.removeById(id);
    },
    /**
     * @description 修改标注图片
     * @param {any} id
     * @param {any} img
     */
    modifyMarkerImg(id, img) {
      markers.staticCzmlDataSource.entities
        .getById(id)
        .billboard.image.setValue(img);
    },
  
    /**
     * @description 高亮图标
     * @param {any} id
     */
    highlightMarker(id) {
      let marker = markers.staticCzmlDataSource.entities.getById(id);
      marker.billboard.image.setValue(marker.properties.higlightImg.getValue());
    },

    /**
     * @description 取消图标高亮
     * @param {any} id
     */
    cancelHighlight(id) {
      let marker = markers.staticCzmlDataSource.entities.getById(id);
      marker.billboard.image.setValue(marker.properties.image.getValue());
    }
  },
  mounted() {
    let self = this;
    viewer = new Motor.Viewer({
      container: "container", //dom元素对象或者id
      viewerMode: Motor.ViewerMode.BIM,
      map: new Motor.WebMapTileService({
        url:
          "https://map.geoq.cn/arcgis/rest/services/ChinaOnlineCommunity/MapServer/WMTS",
        layer: "ChinaOnlineCommunity",
        style: "default",
        tileMatrixSetID: "default028mm",
        maximumLevel: 15,
        tilingScheme: Motor.TilingScheme.WebMercatorTilingScheme
      }),
      appid: "15817c182f79432e80b1ee5969ed100f",
      secret: "650b91f94ace681c8ae2b1215e2f2900",
      backgroundColor: new Motor.Color(0.0, 0.0, 0.0, 0.95),
      enableBloom: false,
      enableBIMViewCube: false
    });
    
    viewer.readyPromise.then(function() {
      let promise = viewer.loadSubProject({
        projectId: projectId,
        drawEdge: true,
        luminanceAtZenith: 0.3
      });

      promise.then(() => {
        let scene = viewer.currentScene;
        scene.setColorForAll(modelColor);
        markers = new Motor.MarkerCollection({
          viewer: viewer
        });
        viewer.addMouseEventListener(Motor.MouseEventType.LEFT_CLICK, function(
          mouse
        ) {
          handler.fire("click", mouse);
        });
        handler.on("click", function(e) {
          let obj = viewer.pick(e.position);
          let coor = viewer.pickPosition(e.position);
          self.$emit("pick", {
            position: e.position,
            coordinate: coor,
            obj: obj
          });
        });
      });
    });
  },
  watch: {
    /**
     * @description 夜景实景切换
     * @param {any} val
     */
    isLight: function(val) {
      modelColor = val
        ? new Motor.Color(102 / 255, 204 / 255, 1.0, 0.5)
        : new Motor.Color(1.0, 1.0, 1.0, 1.0);
      this.changeFloor(this.floor, false);
    },
    /**
     * @description 楼层切换
     * @param {any} val
     */
    floor: function(val) {
      this.changeFloor(val, true);
    },
    /**
     * @description 编辑模式
     * @param {any} val
     */
    editMode: function(val) {
      let self = this;
      if (val) {
        viewer.addMouseEventListener(Motor.MouseEventType.LEFT_DOWN, function(
          mouse
        ) {
          let obj = viewer.pick(mouse.position);
          let coordinate = viewer.pickPosition(mouse.position);
          if (obj instanceof Motor.MarkerView) {
            self.$emit("startEdit", {
              obj: obj,
              position: mouse.position,
              coordinate: obj._entity._position._value
            });
            floatAttribute = {
              id: obj.id,
              image: obj._entity.billboard.image.getValue().url,
              properties: obj.properties
            };
            self.addMarker({
              coordinate: markers.staticCzmlDataSource.entities.getById(
                floatAttribute.id
              ).position._value,
              id: floatAttribute.id,
              image: floatAttribute.properties.higlightImg
                ? floatAttribute.properties.higlightImg
                : floatAttribute.image,
              properties: floatAttribute.properties
            });
          }
        });
        viewer.addMouseEventListener(Motor.MouseEventType.MOUSE_MOVE, function(
          e
        ) {
          let obj = viewer.pick(e.endPosition);
          let coordinate = viewer.pickPosition(e.endPosition);
          if (coordinate && floatAttribute && !floating) {
            self.$emit("editing", {
              position: e.endPosition
            });
            floating = true;
            self.addMarker({
              coordinate: coordinate,
              id: floatAttribute.id,
              image: floatAttribute.properties.higlightImg
                ? floatAttribute.properties.higlightImg
                : floatAttribute.image,
              properties: floatAttribute.properties
            });
            floating = false;
          }
        });
        viewer.addMouseEventListener(Motor.MouseEventType.LEFT_UP, function(
          mouse
        ) {
          let obj = viewer.pick(mouse.position);
          let coordinate = viewer.pickPosition(mouse.position);
          if (coordinate) {
            self.$emit("endEdit", {
              position: mouse.position
            });
            self.addMarker({
              coordinate: coordinate,
              id: floatAttribute.id,
              image: floatAttribute.image,
              properties: floatAttribute.properties
            });
            floatAttribute = null;
          }
        });
      } else {
        viewer.removeMouseEventListener(Motor.MouseEventType.LEFT_DOWN);
        viewer.removeMouseEventListener(Motor.MouseEventType.MOUSE_MOVE);
        viewer.removeMouseEventListener(Motor.MouseEventType.LEFT_UP);
      }
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->

<style scoped>
#container {
  margin: 0;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
</style>
