<template >
  <div style="width:100%;height:100%;">
    <Scene
      :isLight="isLight"
      :floor="floor"
      :editMode="editMode"
      ref="scene"
      @pick="pick"
      @startEdit="startEdit"
      @editing="editing"
      @endEdit="endEdit"
    >
      <a-select
        size="default"
        defaultValue="a1"
        style="width: 150px;position:absolute;top:25px;left:50px;z-index:1000"
        v-model="floor"
      >
        <a-select-option v-for="i in 11" :key="i">{{i===11?"DL":i+"楼"}}</a-select-option>
      </a-select>
      <a-switch
        v-model="isLight"
        checkedChildren="夜光"
        unCheckedChildren="实景"
        defaultChecked
        style="width: 75px;position:absolute;top:75px;left:50px;z-index:1000"
      />
      <a-button
        type="primary"
        style="width: 100px;position:absolute;top:125px;left:50px;z-index:1000"
        @click="pickPosition"
      >添加标注</a-button>
      <a-switch
        v-model="editMode"
        checkedChildren="编辑"
        unCheckedChildren="普通"
        style="width: 75px;position:absolute;top:175px;left:50px;z-index:1000"
      />
      <a-modal title="添加标注" v-model="showModal" @ok="ok" okText="确认" cancelText="取消">
       <a-input v-model="addId" placeholder="输入添加标注id"/>
      </a-modal>
    </Scene>
  </div>
</template>


<script>
import Scene from "./Scene";
import MarkerImage from "../assets/Marker.svg";
import MarkerLi from "../assets/Marker li.svg";
export default {
  name: "Output",
  data() {
    return {
      isLight: true,
      floor: 11,
      markers: [],
      addMode: false,
      editMode: false,
      showModal: false,
      addData:{},
      addId:''
    };
  },
  components: { Scene },
  methods: {
    ok() {
      let data=this.addData;
      this.$refs.scene.addMarker({
        coordinate: data.coordinate,
        id: this.addId,
        image: MarkerImage,
        properties: {
          higlightImg: MarkerLi
        }
      });
      this.addMode = false;
      this.showModal = false;
    },
    pickPosition() {
      this.addMode = true;
       this.$message.info('点击模型添加标注!');
    },
    pick(data) {
      if (this.addMode && data.coordinate) {
        this.showModal = true;
        this.addData=data 
      }
    },
    startEdit(data) {
      console.log("start");
    },
    editing(data) {
      console.log("editing");
    },
    endEdit(data) {
      console.log("end");
    }
  }
};
</script>