#🍎服务端开发环境
cross-env NODE_ENV=development nodemon ./dist/app.js