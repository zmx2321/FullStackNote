const HtmlWebpackPlugin = require('html-webpack-plugin');
const htmlAfterPlugin = require("./config/htmlAfterPlugin");
const { join } = require("path");
const argv = require("yargs-parser")(process.argv.slice(2));
const _mode = argv.mode || "development";
const _mergeConfig = require(`./config/webpack.${_mode}.js`);
const merge = require("webpack-merge");
const glob = require("glob");
//寻找_entry
const files = glob.sync("./src/web/views/**/*.entry.js");
let _entry = {};
let _plguins = [];
for (let item of files) {
    //./src/web/views/books/books-index.entry.js
    // {
    //     books-index:"./src/web/views/booksbooks-index.entry.js",
    //     books-list:"./src/web/views/books/books-list.entry.js"
    // }
    // console.log(item);
    if (/.+\/([a-zA-Z]+-[a-zA-Z]+)(\.entry\.js$)/g.test(item) == true) {
        const entryKey = RegExp.$1;
        //    console.log(entryKey);
        const [dist, template] = entryKey.split("-");
        _entry[entryKey] = item;
        _plguins.push(new HtmlWebpackPlugin({
            filename: `../views/${dist}/pages/${template}.html`,
            template: `src/web/views/${dist}/pages/${template}.html`,
            inject: false,
            chunks: [entryKey]
        }));
    }
}

const webpackConfig = {
    entry: _entry,
    output: {
        path: join(__dirname, "./dist/assets"),
        publicPath:"/",
        filename: "scripts/[name].bundle.js"
    },
    module: {
        rules: [
            {
                test: /\.?js$/,
                exclude: /(node_modules|bower_components)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            }
        ]
    },
    plugins: [
        ..._plguins,
        new htmlAfterPlugin()
    ]
}
module.exports = merge(webpackConfig, _mergeConfig);