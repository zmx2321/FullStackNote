const list = {
    init() {
        console.log("list js入口文件");
    }
}
export default list;