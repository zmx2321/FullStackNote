import cheerio from "cheerio";
import { route, GET } from "awilix-koa";
import { Readable } from "stream";
@route("/books")
class BooksController {
    constructor({ booksService }) {
        this.booksService = booksService;
    }
    @route("/add")
    @GET()
    async actionAdd(ctx, next) {
        // console.log(init);
        ctx.body = await ctx.render('books/pages/add');
    }
    @route("/list")
    @GET()
    async actionList(ctx, next) {
        const result = await this.booksService.getData();
        const html = await ctx.render('books/pages/list', {
            data: result.data
        });
        if (ctx.request.header["x-pjax"]) {
            ctx.status = 200;
            ctx.type = "html";
            console.log("站内跳");
            const $ = cheerio.load(html);
            // ctx.body = $("#js-hooks-data").html()
            let _result = "";
            $(".pjaxcontext").each(function () {
                // _result += $(this).html()
                ctx.res.write($(this).html());
            });
            $(".lazyload-js").each(function () {
                //_result += `<script src="${$(this).attr("src")}"></script>`;
                //核心basket.js
                //ctx.res.write(`<script>activeJS("${$(this).attr("src")}")</script>`);
                ctx.res.write(`<script src="${$(this).attr("src")}"></script>`);
            });
            ctx.res.end();
            // ctx.body = _result;
        } else {
            console.log("直接刷");
            function createSSRStreamPromise() {
                return new Promise((reslove, reject) => {
                    const htmlStream = new Readable();
                    htmlStream.push(html);
                    htmlStream.push(null);
                    ctx.status = 200;
                    ctx.type = "html";
                    htmlStream.on("error", err => { reject(err) }).pipe(ctx.res);
                })
            }
            await createSSRStreamPromise();
            // ctx.body = html;
        }
        // console.log(result);
    }
}
export default BooksController;