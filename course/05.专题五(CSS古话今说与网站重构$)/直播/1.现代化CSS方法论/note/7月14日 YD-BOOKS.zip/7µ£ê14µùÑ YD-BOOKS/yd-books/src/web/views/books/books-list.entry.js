import list from "../../components/list/list.js";
list.init();