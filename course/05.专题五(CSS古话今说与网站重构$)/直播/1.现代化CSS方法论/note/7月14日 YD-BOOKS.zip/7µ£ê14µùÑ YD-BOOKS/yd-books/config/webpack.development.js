const { join, resolve } = require("path");
const WebpackBuildNotifierPlugin = require('webpack-build-notifier');
const FriendlyErrorsWebpackPlugin = require('friendly-errors-webpack-plugin');
const setTitle = require('node-bash-title');
const CopyPlugin = require('copy-webpack-plugin');
setTitle('🍻 开发环境运行');
// var setIterm2Badge = require('set-iterm2-badge');
// var port = '8088';
// setIterm2Badge(port);
module.exports = {
    devServer: {
        contentBase: join(__dirname, "../dist"),
        quiet: true,
        hot: true
    },
    plugins: [
        new CopyPlugin([
            { from: join(__dirname, "../", "src/web/views/layouts/layout.html"), to: '../views/layouts/layout.html' },
        ]),
        new CopyPlugin([
            { from: join(__dirname, "../", "src/web/components"), to: '../components' },
        ], {
                ignore: ["*.js", "*.css", ".DS_Store"]
            }),
        new WebpackBuildNotifierPlugin({
            title: "My Project Webpack Build",
            logo: resolve("./dogs.png"),
            suppressSuccess: true
        }),
        new FriendlyErrorsWebpackPlugin({
            compilationSuccessInfo: {
                messages: ['You application is running here http://localhost:3000'],
                notes: ['请在开发阶段使用npm run client:server']
            }
        }),
    ]
}