class Index {
    constructor(str){
        this.str = str;
    }
    say(){
        console.log(this.str);
    }
}
const index = new Index("🍌老袁666");
index.say();
export default Index;