#🍎web端的部署环境
webpack --mode development --modules module