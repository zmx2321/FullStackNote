import TAGS from "../constant/TAGS";
import Router from "koa-router";
export {
    Container,
    inject
} from "inversify";
//import { provide, buildProviderModule } from "inversify-binding-decorators";
export {
    provide,
    buildProviderModule
} from "inversify-binding-decorators";
export {
    interfaces,
    controller,
    httpGet,
    TYPE
} from "inversify-koa-utils"
export { TAGS,Router };