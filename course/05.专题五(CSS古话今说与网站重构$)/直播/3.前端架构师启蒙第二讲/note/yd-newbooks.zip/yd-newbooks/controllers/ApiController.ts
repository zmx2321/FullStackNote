import { interfaces, controller, httpGet, TYPE, inject, TAGS,Router } from "../ioc";
import { IApi } from "../interface/IApi";
export default class ApiController implements interfaces.Controller {
    private apiService:IApi;
    constructor(@inject(TAGS.ApiService) apiService) {
        this.apiService = apiService;
    }
    private async test(ctx:Router.IRouterContext){
        ctx.body = 123
    }
}