function f() {
    console.log("f(): evaluated");
    return function (target, propertyKey: string, descriptor: PropertyDescriptor) {
        console.log("f(): called");
    }
}

function g() {
    console.log("g(): evaluated");
    return function (target, propertyKey: string, descriptor: PropertyDescriptor) {
        console.log("propertyKey",propertyKey);
        console.log("g(): called");
    }
}

class C {
    @f()
    @g()
    test() { }
}
new C();