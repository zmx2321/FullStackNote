//=========泛型===========
interface Lengthwise {
  length: number;
}
function identity<T extends Lengthwise>(arg: T): T {
  console.log("👴", arg.length);
  return arg;
  //   return "🌶";
}

const str = "typescript学习";
const result = identity<string>(str);
console.log(result);

//=======工具===========
class GenericNumber<T> {
  zeroValue: T;
  add: (x: T, y: T) => T;
}

let myGenericNumber = new GenericNumber<number>();
myGenericNumber.zeroValue = 0;
myGenericNumber.add = function(x, y) {
  return x + y;
};

console.log(myGenericNumber.add(30, 50));
