const TAGS = {
    ApiService: Symbol("ApiService")
}
export default TAGS;