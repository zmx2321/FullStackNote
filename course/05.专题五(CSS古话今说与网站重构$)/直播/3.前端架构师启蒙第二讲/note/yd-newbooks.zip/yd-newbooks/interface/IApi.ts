export interface IApi {
    getInfo(url: string, arg?: object, callback?: Function): Promise<Object>
}