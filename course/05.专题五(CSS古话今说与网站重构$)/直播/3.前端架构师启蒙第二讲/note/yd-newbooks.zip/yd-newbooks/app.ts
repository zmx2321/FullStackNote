import "reflect-metadata";
import "./ioc/inversify.config";
import { Container, buildProviderModule } from "./ioc";
import { InversifyKoaServer } from "inversify-koa-utils";
// import TAGS from "./constant/TAGS";
//初始化这个容器
const container = new Container();
const server = new InversifyKoaServer(container);
container.load(buildProviderModule());
// console.log(container.get(TAGS.ApiService));
const app = server.build();
app.listen(3000, () => {
    console.log("yd-ioc server启动成功🍺");
})