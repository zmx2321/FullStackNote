const Koa = require('./diykoa/application');
const app = new Koa();
app.context.render = function () {
    console.log("🐈我是插件");
}
app.use(async (ctx, next) => {
    console.log(1);
    await next();
    console.log(5);
});
app.use(async (ctx, next) => {
    console.log(2);
    await next();
    console.log(4);
});
app.use(async (ctx, next) => {
    console.log(3);
    // ctx.status = "文字code";
    ctx.render();
    ctx.body = 'Hello World';
    // Promise.resolve()
    await next();
});
app.listen(3000, () => {
    console.log("服务创建成功");
});
app.on("error", function (err) {
    console.log("🐶", err);
})