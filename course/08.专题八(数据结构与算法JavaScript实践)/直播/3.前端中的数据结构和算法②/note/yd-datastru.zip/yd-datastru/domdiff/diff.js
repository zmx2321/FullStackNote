// 1.属性变了
// {
//     type:"ATTRS",
//     attrs:{class:"list-new"}
// }
// 2.文本变了
// {
//     type: "TEXT",
//     text: newTree
// }
// 3.节点被删除
// {
//     type: "REMOVE",
//     index
// }
// 4.节点不一样
// {
//     type: "REPLACE",
//     newNode:newNode
// }
import _ from "./util.js";
let patchs = Object.create(null);
let globalIndex = 0;
function diff(oldTree, newTree) {
    dfswalk(oldTree, newTree, globalIndex);
    return patchs;
}
function dfswalk(oldTree, newTree, index) {
    let currentPatchs = [];
    if (!newTree) {
        currentPatchs.push({
            type: "REMOVE",
            index
        })
    } else if (_.isString(oldTree)) {
        if (_.isString(newTree) && oldTree !== newTree) {
            currentPatchs.push({
                type: "TEXT",
                text: newTree
            })
        }
    } else if (oldTree.type == newTree.type) {
        diffChildren(oldTree.children, newTree.children);
    }
    if (currentPatchs.length > 0) {
        patchs[index] = currentPatchs;
    }
}
function diffProps() {
}
function diffChildren(oldChildrens, newChildrens) {
    oldChildrens.forEach((child, idx) => {
        dfswalk(child, newChildrens[idx], ++globalIndex)
    });
}
export {
    diff
}