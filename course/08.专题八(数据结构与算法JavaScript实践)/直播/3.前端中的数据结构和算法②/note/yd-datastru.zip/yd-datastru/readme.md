1.执行栈 ECS Execution Context Stack 
2.每一个函数都会创建一个EC 
3.每一个函数执行的时候 都会把自己塞进到ECStack 
4.全局对象 GC = Global Context
5.ECStack = [
    test（EC）,
    GC
]
6.VO 变量对象 Variable Object
  AO 活动对象 Activation Object 
  GO 全局Global Object
7.VO(GC) = GO
VO(test) = AO
8.        var a = 10;
        function test(x){
            
            var b = 20;
        }
        test(30);
        // VO(globalContext) = {
        //     a:10,
        //     test:<function>
        // }
        //VO(globalContext) = GO
        // VO(test) = {
        //     x:30,
        //     b:20
        // }
        // test 执行的时候创建了arguments
        // VO(test) = AO(test) ={
        //     arguments,
        //     x:30,
        //     b:20
        // }
    9.   AO(test) = {
             b:undefined,
         }
         AO(test) = {
             b:10
         }
  10.test（EC）= {
        scopeChain:Scopes,
        AO = {
             b:10,
             arguments
         }, 
         VO:{},
         Scopes:[AO,VO,GO]
        this:{运行时确定} 
  }