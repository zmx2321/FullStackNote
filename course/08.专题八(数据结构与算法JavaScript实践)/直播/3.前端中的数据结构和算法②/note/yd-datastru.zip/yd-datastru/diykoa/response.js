module.exports = {
    get body() {
        return this._body;
    },
    set body(data) {
        this._body = data;
    },
    get status() {
        return this.res.statusCode;
    },
    set status(statusCode) {
        console.log("状态码",statusCode);
        if (typeof statusCode !== "number") {
            throw new Error("status code must bu number");
        }
        console.log("xxxx", this.response);
        this.res.statusCode = statusCode;
    }
}