import compose from "./compose.js";
const applyMiddleware = function (...middlewares) {
    return function (oldCreateStore) {
        return function newCreateStore(reducer, initState) {
            const store = oldCreateStore(reducer, initState);
            // 1.调用一下整个中间件 
            // const logger = loggerMiddleware(store);
            // 2.目的还是中间件依次的执行
            //  time(logger(next));
            // let dispatch = store.dispatch;
            const chain = middlewares.map(middleware => middleware(store));
            // console.log("生成的链",chain);
            // chain.reverse().map(middleware => {
            //     dispatch = middleware(dispatch);
            // });
            // console.log("生成的结果", dispatch);
            // store.dispatch = dispatch;
            // return store;
            const dispatch = compose(...chain)(store.dispatch);
            return {
                ...store,
                dispatch
            }
        }
    }
}
export default applyMiddleware;