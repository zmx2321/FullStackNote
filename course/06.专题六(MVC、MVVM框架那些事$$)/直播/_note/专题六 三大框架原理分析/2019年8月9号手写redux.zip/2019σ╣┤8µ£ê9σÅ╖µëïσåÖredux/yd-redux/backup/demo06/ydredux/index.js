import { createStore, combineReducers, applyMiddleware } from "./redux/index.js";
import counterReduer from "./reducers/counter.js";
import infoReduer from "./reducers/info.js";
//引入我们的中间件
import loggerMiddleware from "./middlewares/loggerMiddleware.js";
import timeMiddleware from "./middlewares/timeMiddleware.js";
const reducer = combineReducers({
  counter: counterReduer,
  info: infoReduer
});
const rewriteCreateStoreFunc = applyMiddleware(timeMiddleware, loggerMiddleware);
let store = createStore(reducer, {}, rewriteCreateStoreFunc);
store.subscribe(() => {
  let state = store.getState();
  console.log("获取当前的状态", state);
});
store.dispatch({
  type: "INCERMENT"
});
store.dispatch({
  type: "DECREMENT"
});