import { createStore, combineReducers } from "./redux/index.js";
import counterReduer from "./reducers/counter.js";
import infoReduer from "./reducers/info.js";
//引入我们的中间件
import loggerMiddleware from "./middlewares/loggerMiddleware.js";
import timeMiddleware from "./middlewares/timeMiddleware.js";
const reducer = combineReducers({
  counter: counterReduer,
  info: infoReduer
});
let store = createStore(reducer);
const logger = loggerMiddleware(store);
const time = timeMiddleware(store);
//middleware 是对dispatch
//原有的dispatch做一个引用
const next = store.dispatch;
//科里化函数+函数组合
store.dispatch = time(logger(next));
store.subscribe(() => {
  let state = store.getState();
  console.log("获取当前的状态", state);
});
store.dispatch({
  type: "INCERMENT"
});
store.dispatch({
  type: "DECREMENT"
});