//具体的执行函数
function incerment() {
    return { type: "INCERMENT" }
    // return (dispatch, getState) => {
    //     dispatch({ type: "INCERMENT" },"success");
    // }
}
export { incerment };

