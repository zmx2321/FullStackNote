import { createStore, combineReducers } from "./redux/index.js";
import counterReduer from "./reducers/counter.js";
import infoReduer from "./reducers/info.js";
const reducer = combineReducers({
  counter: counterReduer
});
// let store = createStore(reducer, initState);
let store = createStore(reducer);
const nextReducer = combineReducers({
  counter: counterReduer,
  info: infoReduer
});
store.replaceReducer(nextReducer);
console.log("取当前的默认状态", store.getState());
store.subscribe(() => {
  let state = store.getState();
  console.log("获取当前的状态", state);
});
store.dispatch({
  type: "INCERMENT"
});
store.dispatch({
  type: "SET_NAME",
  name: "京程一灯🏮"
});

