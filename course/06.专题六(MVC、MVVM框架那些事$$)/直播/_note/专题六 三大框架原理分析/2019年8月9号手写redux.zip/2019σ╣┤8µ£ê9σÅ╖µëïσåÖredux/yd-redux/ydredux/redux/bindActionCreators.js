// vuex ...mapActions == actions 里面的action都取出来
function bindActionCreator(actionCreators, dispatch) {
    return function () {
        return dispatch(actionCreators.apply(this, arguments));
    }
}
export default function bindActionCreators(actionCreators, dispatch) {
    if (typeof actionCreators === "function") {
        return bindActionCreator(actionCreators, dispatch);
    }
    if (typeof actionCreators !== "object" || actionCreators === null) {
        throw new Error("actionCreators必须是函数或者数组");
    }
    const keys = Object.entries(actionCreators);
    const boundActionsCreators = {};
    for (let item of keys) {
        const [key, actionCreator] = item;
        if (typeof actionCreator === "function") {
            boundActionsCreators[key] = bindActionCreator(actionCreator, dispatch);
        }
    }
    console.log("合并好的Action",boundActionsCreators);
    return boundActionsCreators;
}