import { createStore } from "./redux/index.js";
let initState = {
  counter: {
    count: 0
  },
  info: {
    name: "",
    description: ""
  }
};
let store = createStore(initState);
store.subscribe(() => {
    let state = store.getState();
    console.log("获取当前的状态",state);
});

setTimeout(function(){
    store.changState({
        ...store.getState(),
        info: {
          name: "京程一灯",
          description: "深圳Redux分析课"
        }
      });
},2000);

