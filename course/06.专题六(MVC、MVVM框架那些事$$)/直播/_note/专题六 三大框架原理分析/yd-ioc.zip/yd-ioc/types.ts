const TYPES = {
    Student: Symbol.for("Student"),
    Teacher: Symbol.for("Teacher"),
    Classroom: Symbol.for("Classroom")
}
export default TYPES;