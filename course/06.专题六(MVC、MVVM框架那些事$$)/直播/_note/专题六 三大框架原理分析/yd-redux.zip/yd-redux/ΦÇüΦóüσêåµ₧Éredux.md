Redux分析
回一下第一周刚来的第一节
1.范畴论 世界对象和对象之间的关系 
container -> store
__value => currentState
f  => action
map => currentReducer
IO函子 => middleware
2.------------------------------------
applyMiddleware.js     redux管理中间件
bindActionCreators.js   能让我们直接的调用action
combineReducers.js     合并reducer
compose.js              组合函数 
createStore.js           创建一个store容器
index.js                
utils
3.react 纯函数
4.状态不能被修改