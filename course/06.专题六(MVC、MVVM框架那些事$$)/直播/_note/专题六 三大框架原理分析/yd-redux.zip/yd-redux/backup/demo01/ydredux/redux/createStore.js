export default function createStore(initState) {
  let state = initState;
  let listeners = [];
  function getState() {
    return state;
  }
  function subscribe(listener) {
    listeners.push(listener);
  }
  function changState(newState) {
    state = newState;
    //通知
    for (const listener of listeners) {
        listener();
    }
  }
  return {
    getState,
    subscribe,
    changState
  };
}
