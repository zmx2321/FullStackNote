import { createStore } from "./redux/index.js";
import reducer from "./reducer.js";
let initState = {
  count: 0
};
let store = createStore(reducer, initState);
store.subscribe(() => {
  let state = store.getState();
  console.log("获取当前的状态", state);
});

store.dispatch({
  type: "INCERMENT"
});
