export default function createStore(reducer, initState) {
  let state = initState;
  let listeners = [];
  function getState() {
    return state;
  }
  function subscribe(listener) {
    listeners.push(listener);
  }
  function dispatch(action) {
    state = reducer(state, action);
    //通知
    for (const listener of listeners) {
      listener();
    }
  }
  //默认合成所有reducer状态
  dispatch({type:Symbol()});
  return {
    getState,
    subscribe,
    dispatch
  };
}
