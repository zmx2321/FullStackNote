class CreateIoc {
    public container;
    constructor() {
        this.container = new Map();
    }
    get(namespace) {
        let item = this.container.get(namespace);
        return item.callback();
    }
    bind(key, callback) {
        this.container.set(key, { callback });
    }
}
export {
    CreateIoc
}
