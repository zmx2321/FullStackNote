import "reflect-metadata";
import { CreateIoc } from "./ioc";
import utils from "./utils"
const container = new CreateIoc();
//Reflect.defineMetadata(TYPES.IndexService, new IndexService(), container);
//Reflect.getMetadata(TYPES.IndexService, container)
const TYPES = {
  IndexService: Symbol("IndexService")
}
class IndexService {
  log(str) {
    console.log(str);
  }
}
//注入到容器中
container.bind(TYPES.IndexService, () => new IndexService());
//进行注入的过程
function inject(serviceIdentifier) {
  return function (target, targetKey, index) {
    if (index == 0) {
      console.log("2️⃣ 🚀 构造函数的装饰器");
      console.log("target", container.get(TYPES.IndexService));
      Reflect.defineMetadata(serviceIdentifier, container.get(serviceIdentifier), target);
    }
  }
}
function controller<T extends { new(...args: any[]): {} }>(constructor: T) {
  console.log("1️⃣ 🚀 整个类的装饰器");
  //todos 取到constructor里的参数值
  // console.log("constructor", constructor);
  //动态类的注入constructor的参数
  // console.log("获取函数参数名称", getArgs(constructor));
  const injectParms = utils.getArgs(constructor);
  class Controller extends constructor {
    constructor(...args: any[]) {
      super(args);
      //利用JavaScript无限constructor的原理强行动态注入参数
      const me = this;
      for (let identity of injectParms) {
        const _identity = utils.firstUpperCase(identity)
        me[identity] = Reflect.getMetadata(TYPES[_identity], constructor)
      }

    }
  }
  return Controller;
}

@controller
class IndexController {
  public indexService;
  constructor(@inject(TYPES.IndexService) indexService) {
    this.indexService = indexService;
  }
  info() {
    console.log(this.indexService);
    this.indexService.log("🍎注入成功");
  }
}
const indexController = new IndexController("");
indexController.info()
// console.log("🍊indexService",indexController.newProperty);
// console.log("🍊通过2个挂载的属性值",indexController.hello);