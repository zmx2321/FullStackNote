System.register([], function (_export, _context) {
  "use strict";

  var data;
  return {
    setters: [],
    execute: function () {
      data = "京程一灯";

      _export("default", data);
    }
  };
});
