const _ =  require("./yd.js");
_.map();