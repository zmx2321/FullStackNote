function util() { }
util.isString = (node) => {
    return typeof node === "string";
}
export default util;