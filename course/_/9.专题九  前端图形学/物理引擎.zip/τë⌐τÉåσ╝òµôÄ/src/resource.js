var res = {
    HelloWorld_png: "res/HelloWorld.png",
    bg_jpg: "res/bg.jpeg",
    snowman_png: "res/snowman.png",
    stone_png: "res/stone.png",
    First_plist:"res/particle_texture.plist"
};

var g_resources = [];
for (var i in res) {
    g_resources.push(res[i]);
}
