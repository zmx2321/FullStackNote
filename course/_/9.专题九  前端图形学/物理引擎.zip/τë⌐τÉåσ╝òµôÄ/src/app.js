var SPRITE_HEIGHT = 64;
var SPRITE_WIDTH = 64;
var COLLISION_TYPE = 1;
var HelloWorldLayer = cc.Layer.extend({
    sprite: null,
    ctor: function () {
        this._super();
        var sprite = new cc.Sprite(res.bg_jpg);
        var size = cc.winSize;
        this.addChild(sprite);
        sprite.setPosition(size.width / 2, size.height / 2);
        //初始化物理引擎
        this.initPhysics();
        //开启游戏的主循环
        this.scheduleUpdate();
        return true;
    },
    onEnter: function () {
        this._super();
        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            onTouchBegan: this.onTouchBegan
        }, this);
    },
    update() {
        var timeStep = 0.04;
        this.space.step(timeStep);
    },
    createBody: function (filename, p) {
        // console.log(filename);
        //创建物体
        var body = new cp.Body(1, cp.momentForBox(1, SPRITE_WIDTH, SPRITE_HEIGHT));
        body.p = p;
        this.space.addBody(body);
        //创建物体的形状
        var shape = new cp.BoxShape(body, SPRITE_WIDTH, SPRITE_HEIGHT);
        //墙的弹性系数
        shape.setElasticity = 0.5;
        //墙的摩擦系数
        shape.setFriction = 0.5;
        shape.setCollisionType(COLLISION_TYPE);
        this.space.addShape(shape);
        //贴纹理
        var sprite = new cc.PhysicsSprite(filename);
        sprite.setBody(body);
        sprite.setPosition(cc.p(p.x, p.y));
        this.addChild(sprite);
        body.data = sprite;
        return body;
    },
    addNewSpriteAtPosition: function (p) {
        // cc.log("addNewSpriteAtPosition")
        var body1 = this.createBody(res.snowman_png, p);
        var body2 = this.createBody(res.stone_png, cc.pAdd(p, cc.p(80, -80)));
        this.space.addConstraint(new cp.PinJoint(body1, body2, cp.v(0, 0), cp.v(0, SPRITE_HEIGHT / 2)));
    },
    onTouchBegan: function (touch, e) {
        var target = e.getCurrentTarget();
        var location = touch.getLocation();
        // console.log(target,position);
        target.addNewSpriteAtPosition(location);
        return false;
    },
    initPhysics: function () {
        var size = cc.winSize;
        //创建一个物理空间
        this.space = new cp.Space();
        //设置物理空间重力加速度
        this.space.gravity = cp.v(0, -100);
        var staticBody = this.space.staticBody;
        var walls = [
            new cp.SegmentShape(staticBody, cp.v(0, 0), cp.v(size.width, 0), 20),
            new cp.SegmentShape(staticBody, cp.v(0, size.height), cp.v(size.width - 800, size.height / 2 + 250), 20)
        ]
        for (var i = 0; i < walls.length; i++) {
            var shape = walls[i];
            //墙的弹性系数
            shape.setElasticity = 1;
            //墙的摩擦系数
            shape.setFriction = 1;
            this.space.addStaticShape(shape);
        }
        this.space.addCollisionHandler(
            COLLISION_TYPE,
            COLLISION_TYPE,
            this.collisionBegan.bind(this),
            this.collisionPre.bind(this),
            this.collisionPost.bind(this),
            this.collisionSeparate.bind(this)
        )
        //开启调试节点
        // this.setDebugNode();
    },
    collisionBegan(arbiter, space) {
        cc.log("collision");
        var shapes = arbiter.getShapes();
        var bodyA = shapes[0].getBody();
        var bodyB = shapes[1].getBody();
        var spriteA = bodyA.data;
        var spriteB = bodyB.data;
        if (spriteA != null && spriteB != null) {
            this.showEffect(spriteA);
        }
    },
    collisionPre() { },
    collisionPost() { },
    collisionSeparate() { },
    showEffect(spriteA) {
        this._particleSystem = new cc.ParticleSystem(res.First_plist);
        this._particleSystem.setAutoRemoveOnFinish(true);
        var position = spriteA.getPosition();
        this._particleSystem.setPositionX(position.x - 10);
        this._particleSystem.setPositionY(position.y);
        this.addChild(this._particleSystem);
    },
    setDebugNode: function () {
        this._debugNode = new cc.PhysicsDebugNode(this.space);
        this._debugNode.visible = true;
        this.addChild(this._debugNode);
    }
});

var HelloWorldScene = cc.Scene.extend({
    onEnter: function () {
        this._super();
        var layer = new HelloWorldLayer();
        this.addChild(layer);
    }
});

