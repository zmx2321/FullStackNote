// a.js -> a.xx44.js
// a.xx44.js -> js内容
window.ma = {
    "a.js": " a.xx44.js"
}
// 1.本地缓存去取 a.js
// 2.有 激活js addScript 

// a.js -> a.xx42.js 对比
// 更新流程a.js -> a.xx44.js 
// a.xx42.js  删除了
// 跳到3

// 3.没有 
// 3-1️ a.xx44.js
// 3-2a.xx44.js 缓存里去