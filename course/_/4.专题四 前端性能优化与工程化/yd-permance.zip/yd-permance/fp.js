const observer = new PerformanceObserver(list => {
    for(const entry of list.getEntries()){
        console.log(entry.name);
        console.log(entry.startTime);
    }
})
observer.observe({
    entryTypes: ["paint"]
})