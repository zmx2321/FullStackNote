    1.网页渲染过程
    1-1.获取Dom分割成多层Parse HTML
    1-2.对每一个层计算样式结果 Recalculate Style
    1-3.为每个节点生成过程图形和位置 重排Layout
    1-4.将每个节点绘制并填充到图层的位图中 重绘Paint
    1-5.绘制出来的纹理上传到GPU Composite Layers
    2.大致的流程 Layout、Paint、Composite Layers
    3.网页分层
    根元素、position、transfrom、半透明、滤镜、canvas、video、overflow
    gpu 参与的好处
    css3d、video、webgl、transform、滤镜

    4.cpu和gpu相同点和不同点
    相同之处：两者总有总线和外界联系，有自己的缓存体系，以及数字和逻辑运算单元，为了完成结算任务而生的。
    不同之处：cpu操作系统和应用程序 gpu显示相关 效率低

    5.属性读会直接造成重排
    重绘不一定引起重排 重排一定会引起重绘
    offset scroll width height 
    读写分离
    ele.height;
    ele.offset;

    下一帧的时候再去设置相关的值
    requestAnimationFrame
    requestIdleCallback