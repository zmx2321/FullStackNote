type ListNode = { data: string | number; next?: ListNode };
// function addNext(node: ListNode) {
//   if (node.next === undefined) {
//     node.next = { data: 0 };
//   }
// }
function setNextValue(node: ListNode, value: number) {
  //   addNext(node);
  node.next!.data = value;
  console.log(node);
}

setNextValue(
  {
    data: 123,
    next: {
      data: 456
    }
  },
  1
);


