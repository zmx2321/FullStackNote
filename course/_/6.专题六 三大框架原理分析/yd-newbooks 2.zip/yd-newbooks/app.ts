import "reflect-metadata";
import "./ioc/inversify.config";
import { Container, buildProviderModule } from "./ioc";
import { InversifyKoaServer } from "inversify-koa-utils";
import * as serve from "koa-static";
import * as render from "koa-swig";
import { wrap } from 'co';
import config from "./config";
import { historyApiFallback } from 'koa2-connect-history-api-fallback';
// import TAGS from "./constant/TAGS";
//初始化这个容器
const container = new Container();
container.load(buildProviderModule());
const server = new InversifyKoaServer(container);
server.setConfig(app => {
    app.context.render = wrap(render({
        root: config.viewDir,
        autoescape: true,
        varControls: ["[[", "]]"],
        // cache: 'memory', // disable, set to false
        cache: false,
        ext: 'html',
        writeBody: false
    }));
    app.use(serve(config.staticDir));
    app.use(historyApiFallback({ index: "/", whiteList: ['/api'] }));
})

// console.log(container.get(TAGS.ApiService));
const app = server.build();
app.listen(config.port, () => {
    console.log("yd-ioc server启动成功🍺");
})