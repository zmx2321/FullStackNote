import { IApi } from "../interface/IApi";
import { provide } from "../ioc";
import TAGS from "../constant/TAGS";
@provide(TAGS.ApiService)
export class ApiService implements IApi {
    private datas: {
        data: "result"
    }
    getInfo(url: string, arg?: object, callback?: Function): Promise<Object> {
        return Promise.resolve(this.datas);
    }
}