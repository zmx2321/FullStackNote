import { interfaces, provideThrowable, controller, httpGet, TYPE, inject, TAGS, Router } from "../ioc";
import { IApi } from "../interface/IApi";

@controller("/api")
@provideThrowable(TYPE.Controller, "ApiController")
export default class ApiController implements interfaces.Controller {
    private apiService: IApi;
    constructor(@inject(TAGS.ApiService) apiService) {
        this.apiService = apiService;
    }
    @httpGet("/test")
    private async test(ctx: Router.IRouterContext, next: () => Promise<any>) {
        ctx.body = {
            result:"京程一灯🏮"
        }
    }
}