// const path = require("path");
// optimization: {
//     runtimeChunk:{
//         name:"runtime"
//     },
//     moduleIds: "hashed",
//     chunkIds: "size"
// }
// module.exports = {
//     module: {
//         rules: [
//             {
//                 test: /\.js$/,
//                 exclude: /(node_modules|bower_components)/,
//                 use: {
//                     loader: path.resolve("./loader/index.js"),
//                     options: {
//                         data: "🍌自定义配置项"
//                     }
//                 }
//             }
//         ]
//     }
// }
const SpeedMeasurePlugin = require("speed-measure-webpack-plugin");
 
const smp = new SpeedMeasurePlugin();
module.exports = smp.wrap({
});