const sysnc = "我是sync模块包🍎";
export default sysnc;