import(/* webpackChunkName:"sync" */  "./sync").then((_) => {
    console.log(_);
});
console.log("我是入口文件");