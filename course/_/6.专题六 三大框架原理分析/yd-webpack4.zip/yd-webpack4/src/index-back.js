import sync from "./sync";
import("./async").then((_) => {
    console.log(_);
});
console.log(sync);
console.log("我是入口文件");