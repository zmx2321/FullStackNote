(function (modules) {
    var installedModules = {};
    function __webpack_require__(moduleId) {
      if (installedModules[moduleId]) {
        return installedModules[moduleId].exports;
      }
      var module = installedModules[moduleId] = {
        exports: {}
      };
      modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
      return module.exports;
    }
    // Load entry module and return exports
    return __webpack_require__("./src/index.js");
  })
    ({
      "./src/index.js":
        (function (module, __webpack_exports__, __webpack_require__) {
          "use strict";
          /* harmony import */
          var _sync__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("./src/sync.js");
          console.log(_sync__WEBPACK_IMPORTED_MODULE_0__["default"]);
          console.log("我是入口文件");
  
        }),
      "./src/sync.js":
        (function (module, __webpack_exports__, __webpack_require__) {
          "use strict";
          const sysnc = "我是sync模块包🍎";
          /* harmony default export */
          __webpack_exports__["default"] = (sysnc);
        })
    });