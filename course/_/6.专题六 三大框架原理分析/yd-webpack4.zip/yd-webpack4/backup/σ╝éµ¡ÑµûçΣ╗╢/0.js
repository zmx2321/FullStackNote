window["webpackJsonp"].push([[0], {
  "./src/async.js":
    (function (module, __webpack_exports__, __webpack_require__) {
      "use strict";
      const asysncData = "我是async模块包🍊";
      /* harmony default export */
      __webpack_exports__["default"] = (asysncData);

    })
}]);

//规则
// [
//   [0],
//   {
//     "./src/async.js": (function () { })
//   }
// ]
//执行规则
// __webpack_require__.e(0).then(
//   __webpack_require__.bind(null, "./src/async.js")).then((_) => {
//        console.log(_); 
//   }
// );