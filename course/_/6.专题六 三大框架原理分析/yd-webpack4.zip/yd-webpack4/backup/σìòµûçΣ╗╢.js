(function (modules) {
  // 模块化的缓存
  var installedModules = {};

  // The require function
  function __webpack_require__(moduleId) {

    // 检查缓存模块是否已经缓存住的js文件
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    // 创建一个新的缓存对象
    // module.exports = {};
    var module = installedModules[moduleId] = {
      exports: {}
    };
    // 执行入口函数
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    return module.exports;
  }
  // 加载入口函数
  return __webpack_require__("./src/index.js");
})
  ({
    "./src/index.js": (function (module, exports) {
      console.log("我是入口文件");
    })
  });