const {
    SyncHook,
    SyncBailHook,
    SyncWaterfallHook,
    SyncLoopHook,
    AsyncParallelHook,
    AsyncParallelBailHook,
    AsyncSeriesHook,
    AsyncSeriesBailHook,
    AsyncSeriesWaterfallHook 
 } = require("tapable");

//1.SyncHook 同步串行的钩子 不关心返回值
//2.SyncBailHook 同步串行 只要监听函数中有一个函数的返回值不为null 跳过剩下的逻辑
//3.SyncWaterfallHook 同步串行 上一个监听函数的返回值可以传给下一个监听函数
//4.SyncLoopHook 同步循环 当监听函数返回true的时候监听函数就反复执行
//5.AsyncParallelHook 异步并发 不关心监听函数返回值
//6.AsyncParallelBailHook 异步并发 返回值不为null 忽略掉后面监听函数
//7.AsyncSeriesHook 异步串行 不关心callback参数
//8.AsyncSeriesBailHook 异步串行 
//9.AsyncSeriesWaterfallHook 异步串行
//发布者
let run = new SyncHook(["compilation"]);

//订阅者
run.tap("1️⃣",function(compilation,name2){
    console.log("1️⃣",compilation,name2);
})
run.tap("2️⃣",function(xxx){
    console.log("2️⃣",xxx);
})
run.tap("3️⃣",function(compilation){
    console.log("3️⃣",compilation);
})

//发布
run.call("webpack","老袁");