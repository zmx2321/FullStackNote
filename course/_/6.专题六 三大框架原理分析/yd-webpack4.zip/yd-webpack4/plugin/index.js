const pluginName = 'ConsoleLogOnBuildWebpackPlugin';

class ConsoleLogOnBuildWebpackPlugin {
    apply(compiler) {
        compiler.hooks.run.tap(pluginName, compilation => {
            console.log("webpack 构建过程开始！");
        });
    }
}
//  compiler 整个编译流程
//  compiler.hooks.run.tap
//compiler.hooks.run == new AsyncSeriesHook(["compiler"]),
//AsyncSeriesHook tapable webpack核心的插件调度全部靠它