1.webpack原理
创建 Compiler -> 
调用 compiler.run 开始构建

创建 Compilation->
基于配置开始创建 Chunk 

使用 Parser 从 Chunk 开始解析依赖 -> 
使用 Module 和 Dependency 管理代码模块相互关系

使用 Template 基于 Compilation 的数据生成结果代码

2.webpack为什么会慢？
loader + plugin + nodejs是单线程 + webpack本身就会慢

3.entry多无解 cache-loader + thread-loader

plugin -》 多核 webpack-parallel-uglify-plugin
optimize-css-assets-webpack-plugin

4.entry多了 削减entry
项目A 
本机免密登录
项目B
#ssh 192.168.21.1
#远程编译的脚本
#scp 拷贝本机的dist

5.合理的devtool 

6.固定chunkid 持久化缓存 name-all-modules-plugin

7.externals 加上引入CDN资源 import vue from "vue"