const asysncData = "我是async模块包🍊";
export default asysncData;