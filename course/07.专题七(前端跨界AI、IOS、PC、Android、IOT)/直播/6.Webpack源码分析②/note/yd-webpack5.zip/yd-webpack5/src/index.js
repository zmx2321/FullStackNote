import("./sync").then((_) => {
    console.log(_);
});
import("./xasync").then((_) => {
    console.log(_);
});
console.log("我是入口文件");
// [name].[contenthash:5].bundle.js