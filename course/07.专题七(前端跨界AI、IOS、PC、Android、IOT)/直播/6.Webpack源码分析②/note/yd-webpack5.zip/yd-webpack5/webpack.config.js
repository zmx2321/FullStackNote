// const path = require("path");
// module.exports = {
//     module: {
//         rules: [
//             {
//                 test: /\.js$/,
//                 exclude: /(node_modules|bower_components)/,
//                 use: {
//                     loader: path.resolve("./loader/index.js"),
//                     options: {
//                         data: "🍌自定义配置项"
//                     }
//                 }
//             }
//         ]
//     }
// }
module.exports = {
    cache:{
        type:"filesystem"
    },
    optimization: {
        splitChunks: {

        },
        minSize: {
            javascript: 0,
            style: 0
        },
        maxSize: {
            javascript: 3000,
            style: 3000
        },
    }
}