const cacheName = "ydPwa-step-v1";
const filesTocache = [
    "/js/index.js",
    "/css/index.css",
    "/images/timg.jpeg",
    "/"
];
self.addEventListener("install", function (event) {
    console.log("sw注册成功");
    event.waitUntil(updateStaticCache());
})
function updateStaticCache() {
    return caches.open(cacheName)
        .then(function (cache) {
            return cache.addAll(filesTocache);
        })
        .then(() => self.skipWaiting());
}
self.addEventListener("active", function (event) {
    event.waitUntil(caches.keys().then(function (keyList) {
        return Promise.all(keyList.map(function (key) {
            if (key !== cacheName) {
                return caches.delete(key);
            }
        }))
    }))
})
self.addEventListener("fetch", function (event) {
    // event.respondWith(new Response("hello world"));
    event.respondWith(
        caches.match(event.request).then(function(response){
            return response || fetch(event.request);
        })
    );
})