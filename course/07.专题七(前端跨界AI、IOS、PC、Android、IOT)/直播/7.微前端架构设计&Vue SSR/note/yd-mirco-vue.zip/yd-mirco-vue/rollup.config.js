const commonjs = require("rollup-plugin-commonjs");
const VuePlugin = require('rollup-plugin-vue');
module.exports = [
    {
        input: "./src/BuyList.vue",
        output: {
            file: "./dist/buylist.dev.bundle.js",
            format: "system"
        },
        plugins: [
            commonjs(),
            VuePlugin()
        ]
    }
]