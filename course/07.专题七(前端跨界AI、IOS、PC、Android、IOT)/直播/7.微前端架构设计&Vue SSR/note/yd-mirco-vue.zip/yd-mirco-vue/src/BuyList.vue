<template>
  <div class="buylist">
    <h1>公用组件</h1>
    <input type="button" value="点击测试" @click="initFn" />
  </div>
</template>

<script>
export default {
  name: "",
  methods: {
    initFn() {
      console.log(Math.random());
    }
  }
};
</script>

<style>
</style>