const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
const webGLRenderer = new THREE.WebGLRenderer({
    alpha: true,
    antialias: true
});
function createMesh(geom, imgFile) {
    const textureLoader = new THREE.TextureLoader();
    const texture = textureLoader.load(`./images/${imgFile}`);
    const mat = new THREE.MeshPhongMaterial({
        normalMap: textureLoader.load('./images/crate0_normal.png')
    });
    mat.map = texture;
    const mesh = new THREE.Mesh(geom, mat);
    return mesh;
}
const mesh1 = createMesh(new THREE.BoxGeometry(10, 10, 10), "crate0_diffuse.png");
scene.add(mesh1);
camera.position.x = 20;
camera.position.y = 5;
camera.position.z = 20;
camera.lookAt(new THREE.Vector3(0, 0, 0));
//环境光
const ambientLight = new THREE.AmbientLight(0x242424);
scene.add(ambientLight);
//聚光灯
const spotLight = new THREE.SpotLight(0xffffff);
spotLight.position.set(10, 10, 5);
scene.add(spotLight);
webGLRenderer.setSize(window.innerWidth, window.innerHeight);
document.body.append(webGLRenderer.domElement);
//聚光灯辅助线
const spotLightHelper = new THREE.SpotLightHelper(spotLight);
scene.add(spotLightHelper);
//系统本身辅助线
const axesHelper = new THREE.AxesHelper(50);
scene.add(axesHelper);
render();
function render() {
    requestAnimationFrame(render);
    mesh1.rotation.y += -0.00255 * Math.PI;
    webGLRenderer.render(scene, camera);
}