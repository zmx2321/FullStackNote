// gltf-pipeline -i 7thWorkshopModelV1.gltf -d -s
// obj2gltf -i 7thWorkshopModelV1.obj -o 7thWorkshopModelV1.gltf -t
let container, camera, scene, light, loader, webGLRenderer;
let objects = [];
init();
render();
function processGLTFChild(child) {
    if (child.isMesh) {
        objects.push(child);
    }
}
function init() {
    container = document.createElement("div");
    document.body.appendChild(container);
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 80, 200);
    scene = new THREE.Scene();
    //添加轨道控制器
    const controls = new THREE.OrbitControls(camera);
    controls.target.set(0, -0.2, -0.2);
    //给场景打光 适合一个半球光
    light = new THREE.HemisphereLight(0xbbbbff, 0x444422);
    light.position.set(0, 1, 0);
    scene.add(light);
    loader = new THREE.GLTFLoader().setPath("./models/7thWorkshopModelV1/");
    const dracoLoader = new THREE.DRACOLoader();
    dracoLoader.setDecoderPath('javascript/');
    // dracoLoader.setDecoderConfig( { type: 'wasm' } );
    loader.setDRACOLoader(dracoLoader);
    loader.load("7thWorkshopModelV1-processed.gltf", function (gltf) {
        gltf.scene.scale.set(0.03, 0.03, 0.03);
        gltf.scene.position.set(-80, 0.03, 0.03);
        gltf.scene.traverse(processGLTFChild)
        scene.add(gltf.scene);
    }, undefined, function (e) {
        console.log("🍎", e);
    })
    webGLRenderer = new THREE.WebGLRenderer({
        antialias: true
    });
    webGLRenderer.setPixelRatio(window.devicePixelRatio);
    webGLRenderer.setSize(window.innerWidth, window.innerHeight);
    container.append(webGLRenderer.domElement);
}
window.addEventListener("mousedown", onDoucumentMouseDown);
var raycaster = new THREE.Raycaster();
var mouse = new THREE.Vector2();
function onDoucumentMouseDown(event) {
    event.preventDefault();
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = - (event.clientY / window.innerHeight) * 2 + 1;
    raycaster.setFromCamera(mouse, camera);
    var intersects = raycaster.intersectObjects(objects);
    if (intersects.length > 0) {
        const INTERSECTED = intersects[0].object;
        console.log("🌶", INTERSECTED.name)
        if (INTERSECTED.name == "hideThisRoof_1_3") {
            INTERSECTED.position.set(0, 1000, 0);
        }
    }
    // for (var i = 0; i < intersects.length; i++) {
    //     intersects[i].object.material.color.set(0xff0000);
    // }
}
function render() {
    requestAnimationFrame(render);
    webGLRenderer.render(scene, camera);
}