const scene = new THREE.Scene();
const textureLoader = new THREE.TextureLoader();
const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
const webGLRenderer = new THREE.WebGLRenderer({
    antialias: true
});
//地板
const floorMat = new THREE.MeshStandardMaterial({
    roughness: 0.8,
    color: 0xffffff,
    metalness: 0.2,
    bumpScale: 0.0005
});
//平面缓冲的几何体
const floorBufferGeometry = new THREE.PlaneBufferGeometry(20, 20);
const floorMesh = new THREE.Mesh(floorBufferGeometry, floorMat);
floorMesh.receiveShadow = true;
textureLoader.load("./images/hardwood2_diffuse.jpg", (map) => {
    floorMat.map = map;
    map.wrapS = THREE.RepeatWrapping;
    map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(10, 24);
    floorMat.needsUpdate = true;
});
floorMesh.rotation.x = -Math.PI / 2;
scene.add(floorMesh);
//往地板里物体
const boxGeometry = new THREE.BoxBufferGeometry(0.5, 0.5, 0.5);
const boxMat = new THREE.MeshStandardMaterial({
    roughness: 0.7,
    color: 0xffffff,
    metalness: 0.002,
    bumpScale: 0.2
});
textureLoader.load("./images/floor2.png", (map) => {
    boxMat.map = map;
    map.wrapS = THREE.RepeatWrapping;
    map.wrapT = THREE.RepeatWrapping;
    map.repeat.set(1, 1);
    boxMat.needsUpdate = true;
});
const boxMesh = new THREE.Mesh(boxGeometry, boxMat);
boxMesh.position.set(-0.5, 0.25, -1);
boxMesh.castShadow = true;
scene.add(boxMesh);
//===============
camera.position.x = -4;
camera.position.y = 2;
camera.position.z = 4;
camera.lookAt(new THREE.Vector3(0, 0, 0));
//添加轨道控制器
const controls = new THREE.OrbitControls(camera);
controls.target.set(0, -0.2, -0.2);
//环境光
// const ambientLight = new THREE.AmbientLight(0xfffff);
// scene.add(ambientLight);
//加点光
const pointLight = new THREE.PointLight(0xffee88, 1, 100, 2);
pointLight.position.set(0, -20, 0);
pointLight.castShadow = true;
scene.add(pointLight);
webGLRenderer.setSize(window.innerWidth, window.innerHeight);
document.body.append(webGLRenderer.domElement);
render();
function render() {
    requestAnimationFrame(render);
    const time = Date.now() * 0.0005;
    webGLRenderer.shadowMap.enabled = true;
    pointLight.position.y = Math.cos(time);
    webGLRenderer.render(scene, camera);
}