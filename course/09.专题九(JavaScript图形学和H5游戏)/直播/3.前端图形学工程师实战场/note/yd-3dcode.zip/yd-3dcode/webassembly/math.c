int add(int x,int y){
    return x+y;
}

int square(int x){
    return x*x;
}