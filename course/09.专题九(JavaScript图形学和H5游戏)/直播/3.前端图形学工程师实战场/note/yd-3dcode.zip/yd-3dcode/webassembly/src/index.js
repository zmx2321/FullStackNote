import("./math.wasm").then(function(_){
    console.log(_);
})