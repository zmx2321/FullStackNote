self.addEventListener("message", (event) => {
    const sharedArrayBuffer = event.data;
    const sharedArray = new Int32Array(sharedArrayBuffer);
    Atomics.wait(sharedArray, 2, 3)
    console.log("🍎");
})