window.add = function (a) {
    if (a == 1) {
        return 1
    } else {
        return a + 1;
    }
}
// module.exports = add;
